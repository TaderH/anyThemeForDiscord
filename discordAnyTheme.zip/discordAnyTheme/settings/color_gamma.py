
def darken_color(color, amount):
    r, g, b = color

    r = max(0, r - amount)
    g = max(0, g - amount)
    b = max(0, b - amount)

    return (r, g, b)

def lighten_color(color, amount):
    r, g, b = color
    
    r = min(255, r + amount)
    g = min(255, g + amount)
    b = min(255, b + amount)
    
    return (r, g, b)

from writeToFile import main

main()

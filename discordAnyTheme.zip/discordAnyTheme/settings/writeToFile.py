import os
import color_gamma
from mostCommonColor import screenshot_take

user_dir = os.path.expanduser("~")
screenshot_color = screenshot_take()


def modify_multiple_lines(file_path, lines_to_modify):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
        
        # Change lines content
        for line_number, new_content in lines_to_modify.items():
            lines[line_number - 1] = new_content + '\n'
        
        # Write content in file
        with open(file_path, 'w') as file:
            file.writelines(lines)
    
    except FileNotFoundError:
        print(f"File '{file_path}' is not found. Check if you have Vencord installed.")
    except Exception as e:
        print(f"Some shitty error occured. Write me. \n{e}")

def main():
    file_path = f'{user_dir}\\AppData\\Roaming\\Vencord\\themes\\Themecord.css'

    lines_to_modify = {
        13: f'    --background-1: rgb{screenshot_color};',
        15: f'    --accent-color: rgb{color_gamma.darken_color(screenshot_color, 20)};',
        17: f'    --text-norma: rgb{color_gamma.lighten_color(screenshot_color, 50)};',
        53: f'    --text-link: rgb{color_gamma.lighten_color(screenshot_color, 100)};',
        111: f'    --scrollbar-auto-thumb: rgb{color_gamma.darken_color(screenshot_color, 105)};'
    }
    
    modify_multiple_lines(file_path, lines_to_modify)



from PIL import ImageGrab
import matplotlib.pyplot as plt
import numpy as np
import time
import pyautogui

def check_color_in_screenshot():
    pyautogui.hotkey('win', 'd')
    time.sleep(2)

    screenshot = ImageGrab.grab()
    screenshot = screenshot.convert("RGB")

    # Перетворити зображення на масив
    image_array = np.array(screenshot)
    
    plt.imshow(screenshot)
    plt.axis('off')  # Не показувати осі
    plt.show()

    return 0

check_color_in_screenshot()
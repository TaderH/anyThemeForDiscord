import os
import pyautogui
import time
from PIL import ImageGrab
from collections import Counter
from colorthief import ColorThief


def get_most_common_color(image):
    rgb_image = image.convert('RGB')
    pixels = list(rgb_image.getdata())
    color_counter = Counter(pixels)
    most_common_color = color_counter.most_common(1)[0][0]
    
    return most_common_color

def screenshot_take():
    pyautogui.hotkey('win', 'd')
    time.sleep(2)
    screenshot = ImageGrab.grab()
    screenshot.save("screenshot.png")
    screenshot.close()
    screenshot = ColorThief('screenshot.png')
    most_common_color = screenshot.get_color(quality=1)
    pyautogui.hotkey('win', 'd')
    os.remove('screenshot.png')
    
    return most_common_color
